export const STATEFUL = 1
export const VNODE_NONE = 0
export const VNODE_TEXT = 1
export const VNODE_ELEMENT = 2
export const VNODE_COMPONENT = 3
export const VNODE_FUNCTION = 4