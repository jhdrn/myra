import './component.spec'
import './helpers.spec'
import './jsxFactory.spec'
import './renderer.spec'